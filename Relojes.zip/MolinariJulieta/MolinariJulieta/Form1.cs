﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MolinariJulieta
{
    public partial class frmRelojes : Form , IEvento
    {
        Relojes relojero;


        public frmRelojes()
        {
            InitializeComponent();
            relojero = new Relojes(3,this);
            
        }

        private void btnIniciar1_Click(object sender, EventArgs e)
        {
            StarStopReloj(Relojes.Reloj.Primero);
        }

        private void btnIniciar2_Click(object sender, EventArgs e)
        {
            StarStopReloj(Relojes.Reloj.Segundo);
        }

        private void btnIniciar3_Click(object sender, EventArgs e)
        {
            StarStopReloj(Relojes.Reloj.Tercero);
        }
        

        private void frmRelojes_Load(object sender, EventArgs e)
        {

        }

        private void frmRelojes_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.relojero.KillEmAll();
        }

        public void ImprimirReloj(Relojes.Reloj reloj, string dato)
        {
            if (this.InvokeRequired)
            {                 
                Contador.EventoReloj d = new Contador.EventoReloj(ImprimirReloj);

                this.Invoke(d, new object[] { reloj, dato });
            }
            else
            {
                switch (reloj)
                {
                    case Relojes.Reloj.Primero:
                        this.lblTimer1.Text = dato;
                        break;
                    case Relojes.Reloj.Segundo:
                        this.lblTimer2.Text = dato;
                        break;
                    case Relojes.Reloj.Tercero:
                        this.lblTimer3.Text = dato;
                        break;
                    default:
                        break;
                }
            }
           
        }

        private void StarStopReloj(Relojes.Reloj reloj)
        {
            try
            {
                relojero.CargarReloj(reloj);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.InnerException.Message);
            }
        }
    }
}
