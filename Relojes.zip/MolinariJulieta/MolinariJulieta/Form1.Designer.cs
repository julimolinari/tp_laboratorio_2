﻿namespace MolinariJulieta
{
    partial class frmRelojes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIniciar1 = new System.Windows.Forms.Button();
            this.lblTimer1 = new System.Windows.Forms.Label();
            this.btnIniciar2 = new System.Windows.Forms.Button();
            this.btnIniciar3 = new System.Windows.Forms.Button();
            this.lblTimer3 = new System.Windows.Forms.Label();
            this.lblTimer2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIniciar1
            // 
            this.btnIniciar1.Location = new System.Drawing.Point(76, 69);
            this.btnIniciar1.Name = "btnIniciar1";
            this.btnIniciar1.Size = new System.Drawing.Size(185, 90);
            this.btnIniciar1.TabIndex = 0;
            this.btnIniciar1.Text = "Contador 1";
            this.btnIniciar1.UseVisualStyleBackColor = true;
            this.btnIniciar1.Click += new System.EventHandler(this.btnIniciar1_Click);
            // 
            // lblTimer1
            // 
            this.lblTimer1.AutoSize = true;
            this.lblTimer1.Location = new System.Drawing.Point(142, 36);
            this.lblTimer1.Name = "lblTimer1";
            this.lblTimer1.Size = new System.Drawing.Size(49, 13);
            this.lblTimer1.TabIndex = 3;
            this.lblTimer1.Text = "00:00:00";
            // 
            // btnIniciar2
            // 
            this.btnIniciar2.Location = new System.Drawing.Point(76, 215);
            this.btnIniciar2.Name = "btnIniciar2";
            this.btnIniciar2.Size = new System.Drawing.Size(185, 90);
            this.btnIniciar2.TabIndex = 7;
            this.btnIniciar2.Text = "Contador 2";
            this.btnIniciar2.UseVisualStyleBackColor = true;
            this.btnIniciar2.Click += new System.EventHandler(this.btnIniciar2_Click);
            // 
            // btnIniciar3
            // 
            this.btnIniciar3.Location = new System.Drawing.Point(76, 359);
            this.btnIniciar3.Name = "btnIniciar3";
            this.btnIniciar3.Size = new System.Drawing.Size(185, 90);
            this.btnIniciar3.TabIndex = 8;
            this.btnIniciar3.Text = "Contador 3";
            this.btnIniciar3.UseVisualStyleBackColor = true;
            this.btnIniciar3.Click += new System.EventHandler(this.btnIniciar3_Click);
            // 
            // lblTimer3
            // 
            this.lblTimer3.AutoSize = true;
            this.lblTimer3.Location = new System.Drawing.Point(142, 334);
            this.lblTimer3.Name = "lblTimer3";
            this.lblTimer3.Size = new System.Drawing.Size(49, 13);
            this.lblTimer3.TabIndex = 5;
            this.lblTimer3.Text = "00:00:00";
            // 
            // lblTimer2
            // 
            this.lblTimer2.AutoSize = true;
            this.lblTimer2.Location = new System.Drawing.Point(142, 190);
            this.lblTimer2.Name = "lblTimer2";
            this.lblTimer2.Size = new System.Drawing.Size(49, 13);
            this.lblTimer2.TabIndex = 6;
            this.lblTimer2.Text = "00:00:00";
            // 
            // frmRelojes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 482);
            this.Controls.Add(this.btnIniciar3);
            this.Controls.Add(this.btnIniciar2);
            this.Controls.Add(this.lblTimer2);
            this.Controls.Add(this.lblTimer3);
            this.Controls.Add(this.lblTimer1);
            this.Controls.Add(this.btnIniciar1);
            this.Name = "frmRelojes";
            this.Text = "Alumna Julieta Molinari";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRelojes_FormClosing);
            this.Load += new System.EventHandler(this.frmRelojes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIniciar1;
        private System.Windows.Forms.Label lblTimer1;
        private System.Windows.Forms.Button btnIniciar2;
        private System.Windows.Forms.Button btnIniciar3;
        private System.Windows.Forms.Label lblTimer3;
        private System.Windows.Forms.Label lblTimer2;
    }
}

