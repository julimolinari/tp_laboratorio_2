﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class ExtenderDateTime
    {
        public static string TiempoTranscurrido(this DateTime dt)
        {            
            TimeSpan date = (DateTime.Now - dt);
            string dif = date.ToString(@"mm\:ss\.ff");
            return dif;

        }

    }
}
