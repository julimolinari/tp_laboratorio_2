﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Relojes : IReloj
    {
        private int cantidad;
        private Dictionary<Reloj, Contador> hilos;
        private IEvento referencia;


        public Relojes CargarReloj(Reloj item)
        {
            Relojes re = this;
            if (this.hilos.ContainsKey(item))
            {
                Contador c;
                this.hilos.TryGetValue(item ,out c);

                if (c.Hilo.IsAlive)
                {
                    c.Hilo.Abort();
                }
                else
                {
                    // no me deja asignar al this directamente                    
                    re -= item;
                    re  += item;

                }
            }else
            {
                
                if (this.cantidad > this.hilos.Count)
                {
                    re += item;
                }else
                {
                    throw new SinEspacioException("cupo de relojes completo");
                }
            }
            return this;
        }

        public void KillEmAll()
        {
            foreach (KeyValuePair<Reloj, Contador> result in this.hilos)
            {
                if (result.Value.Hilo.IsAlive)
                {
                    result.Value.Hilo.Abort();
                }
            }
        }

        public static  Relojes operator + (Relojes r, Reloj item)
        {
            Contador c = new Contador(item,r.referencia);
            r.hilos.Add(item, c);

            return r;
        }

        public static Relojes operator - (Relojes r, Reloj item)
        {
            r.hilos.Remove(item);
            return r;
        }


        private Relojes()
        {
            hilos = new Dictionary<Reloj, Contador>();
        }

        public Relojes(int cantidad, IEvento referencia) : this()
        {
            this.cantidad = cantidad;
            this.referencia = referencia;
        }

        public enum Reloj
        {
            Primero,
            Segundo,
            Tercero
        }

    }
}
