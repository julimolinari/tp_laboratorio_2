﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Contador
    {
        private DateTime inicio;
        private Relojes.Reloj reloj;
        private Thread timer;
        public delegate void EventoReloj(Relojes.Reloj r , string tiempo);
        public event EventoReloj EventoTiempo;

        public Thread Hilo
        {
            get { return this.timer; }
            
        }

        public Contador(Relojes.Reloj r, IEvento imprimir)
        {
            timer = new Thread(EjecutarTimer);            
            timer.Start();
            this.EventoTiempo += imprimir.ImprimirReloj;
        }

        public Contador()
        {
                
        }
        public void EjecutarTimer()
        {
            DateTime dFechainicio = DateTime.Now;            

            do
            {
                string dTranscurrido = dFechainicio.TiempoTranscurrido();
                this.EventoTiempo.Invoke(this.reloj, dTranscurrido);
                Thread.Sleep(100);
            } while (true);
        }

    }
}
